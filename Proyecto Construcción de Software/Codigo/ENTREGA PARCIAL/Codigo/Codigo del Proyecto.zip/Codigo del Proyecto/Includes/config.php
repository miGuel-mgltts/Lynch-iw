<?php
$host = "localhost";
$usuario = "root";
$contrasena = "2004";
$base_datos = "inventario_db";

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verificar conexión
if ($conn->connect_error) {
    // Registrar el error en un archivo de log
    error_log("Error de conexión a la base de datos: " . $conn->connect_error);

    // Mostrar mensaje 
    echo "<p>No se pudo conectar al sistema en este momento. Por favor, intente más tarde.</p>";
    exit();
}
?>
