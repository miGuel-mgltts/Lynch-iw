<?php
session_start();
require_once '../includes/config.php';

// Si el formulario de inicio de sesión es enviado
if (isset($_POST['login'])) {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    // Consulta para verificar si el usuario existe
    $sql = "SELECT * FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario_db = $result->fetch_assoc();

    // Verificar si el usuario existe y la contraseña es correcta
    if ($usuario_db && password_verify($clave, $usuario_db['clave'])) {
        $_SESSION['usuario'] = $usuario_db['usuario'];
        $_SESSION['mensaje'] = "Bienvenido, $usuario";
        header("Location: ../principal.html"); // Redirigir al inicio o a una página protegida
        exit();
    } else {
        $_SESSION['error'] = "Usuario o contraseña incorrectos";
        header("Location: index.php");
        exit();
    }
}

// Si el formulario de registro es enviado
if (isset($_POST['registrar'])) {
    $nombre = $_POST['nombre'];
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    // Verificar si el usuario ya existe
    $sql = "SELECT * FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = "El usuario ya está registrado";
        header("Location: index.php");
        exit();
    }

    // Encriptar la contraseña antes de guardarla
    $clave_encriptada = password_hash($clave, PASSWORD_DEFAULT);

    // Insertar el nuevo usuario en la base de datos
    $sql = "INSERT INTO usuarios (nombre, usuario, clave) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $nombre, $usuario, $clave_encriptada);
    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "Registro exitoso. Ahora puedes iniciar sesión.";
        header("Location: index.php");
        exit();
    } else {
        $_SESSION['error'] = "Hubo un error al registrar el usuario. Intenta de nuevo.";
        header("Location: index.php");
        exit();
    }
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
