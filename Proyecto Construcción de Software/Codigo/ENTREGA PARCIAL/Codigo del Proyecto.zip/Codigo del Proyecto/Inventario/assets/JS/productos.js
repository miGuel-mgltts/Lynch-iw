// FUNCION REGISTRAR
// ==========================
function registrarProducto() {
    const datos = {
        codigo: document.getElementById("codigo").value.trim(),
        nombre: document.getElementById("nombre").value.trim(),
        descripcion: document.getElementById("descripcion").value.trim(),
        categoria: document.getElementById("categoria").value.trim(),
        precio_venta: document.getElementById("precio_venta").value,
        precio_compra: document.getElementById("precio_compra").value,
        stock_inicial: document.getElementById("stock_inicial").value,
        stock_minimo: document.getElementById("stock_minimo").value
    };

    // Validación rápida
    if (!datos.codigo || !datos.nombre || !datos.precio_venta) {
        alert("Código, nombre y precio de venta son obligatorios.");
        return;
    }

    // Enviar vía AJAX (Fetch API)
    fetch('controlador/controladorProductos.php?accion=registrar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    })
    .then(response => response.text())
    .then(msg => {
            const mensajeHTML = `
                <div style="
                    background: #d4edda;
                    color: #155724;
                    border: 1px solid #c3e6cb;
                    padding: 12px 16px;
                    border-radius: 8px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                    margin-bottom: 10px;
                    position: relative;
                    min-width: 250px;
                    font-family: Arial, sans-serif;
                ">
                    <strong>${msg}</strong>
                    <span onclick="this.parentElement.remove();" 
                        style="
                            position: absolute;
                            top: 4px;
                            right: 8px;
                            cursor: pointer;
                            font-weight: bold;
                            color: #155724;
                        ">&times;</span>
                </div>`;
        
            document.getElementById("mensaje").innerHTML = mensajeHTML;
            agregarFila(datos);
        
            document.getElementById("codigo").value = "";
            document.getElementById("nombre").value = "";
            document.getElementById("descripcion").value = "";
            document.getElementById("categoria").value = "";
            document.getElementById("precio_venta").value = "";
            document.getElementById("precio_compra").value = "";
            document.getElementById("stock_inicial").value = "";
            document.getElementById("stock_minimo").value = "";
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Ocurrió un error al registrar.");
    });
}

function agregarFila(datos) {

    const tabla = document.getElementById('tablaProductos').getElementsByTagName('tbody')[0];
    const nuevaFila = tabla.insertRow();
  
    nuevaFila.insertCell(0).textContent = datos.nombre;
    nuevaFila.insertCell(1).textContent = datos.codigo;
    nuevaFila.insertCell(2).textContent = datos.categoria;
    nuevaFila.insertCell(3).textContent = datos.precio_venta;
    nuevaFila.insertCell(4).textContent = datos.stock_inicial;
  
    const celdaAcciones = nuevaFila.insertCell(5);

    // Botón Editar
    const btnEditar = document.createElement('button');
    btnEditar.className = 'btn btn-editar';
    btnEditar.textContent = 'Editar';
    // Aquí podrías agregar funcionalidad de edición si la deseas
    celdaAcciones.appendChild(btnEditar);

    // Botón Eliminar
    const btnEliminar = document.createElement('button');
    btnEliminar.className = 'btn btn-eliminar';
    btnEliminar.textContent = 'Eliminar';
    btnEliminar.onclick = function () {
        const confirmar = confirm("¿Estás seguro de que deseas eliminar este producto?");
        if (confirmar) {
        tabla.deleteRow(nuevaFila.rowIndex - 1);
        }
    };
    celdaAcciones.appendChild(btnEliminar);
}

// // FUNCION FILTRAR
// // ==========================
// function filtrarPorCodigo() {
//     const codigoFiltro = document.getElementById("filtro_codigo").value.trim();
//     if (!codigoFiltro) {
//         alert("Por favor, ingrese un código de producto.");
//         return;
//     }

//     // Realizar la consulta AJAX para filtrar productos
//     fetch('controlador/controladorProductos.php?accion=filtrar', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({ codigo: codigoFiltro })
//     })
//     .then(response => response.json())
//     .then(data => {
//         if (data.success) {
//             mostrarProductos(data.productos); // Muestra los productos filtrados
//         } else {
//         }
//     })
//     .catch(error => {
//         console.error("Error:", error);
//         alert("Ocurrió un error al filtrar los productos.");
//     });
// }

// // Función para mostrar productos filtrados en la tabla
// function mostrarProductos(productos) {
//     const tabla = document.getElementById('tablaProductos').getElementsByTagName('tbody')[0];
//     tabla.innerHTML = ''; // Limpiar la tabla antes de agregar los nuevos productos

//     productos.forEach(producto => {
//         const nuevaFila = tabla.insertRow();
//         nuevaFila.insertCell(0).textContent = producto.nombre;
//         nuevaFila.insertCell(1).textContent = producto.codigo;
//         nuevaFila.insertCell(2).textContent = producto.categoria;
//         nuevaFila.insertCell(3).textContent = producto.precio_venta;
//         nuevaFila.insertCell(4).textContent = producto.stock_inicial;
//     });
// }
