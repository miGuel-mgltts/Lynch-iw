<?php
header("Content-Type: application/json");

// Conexión
require_once '../includes/config.php';

// Leer JSON
$data = json_decode(file_get_contents("php://input"), true);

$accion = $_GET['accion'] ?? null;
//Acción a realizar
switch ($accion) {
    case 'registrar':
        registrarProveedor($conn, $data);
        break;
    case 'filtrar':
        filtrarProveedor($conn, $data);
        break;
    case 'eliminar':
        eliminarProveedor($conn, $data);
        break;
    case 'actualizar':
        actualizarProveedor($conn, $data);
        break;
    default:
        echo json_encode(["success" => false, "message" => "Acción no válida."]);
        break;
}

// ==========================
// FUNCION REGISTRAR
// ==========================

function registrarProveedor($conn, $data) {
    $codigo = $data['codigo'];
    $nombre = $data['nombre'];
    $descripcion = $data['descripcion'];
    $categoria = $data['categoria'];
    $precio_venta = $data['precio_venta'];
    $precio_compra = $data['precio_compra'];
    $stock_inicial = $data['stock_inicial'];
    $stock_minimo = $data['stock_minimo'];

    // Validar si el código existe
    $check = $conn->prepare("SELECT id FROM productos WHERE codigo = ?");
    $check->bind_param("s", $codigo);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "El código ya está registrado.";
        exit;
    }

    // Insertar
    $stmt = $conn->prepare("INSERT INTO productos (codigo, nombre, descripcion, categoria, precio_venta, precio_compra, stock_inicial, stock_minimo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssddii", $codigo, $nombre, $descripcion, $categoria, $precio_venta, $precio_compra, $stock_inicial, $stock_minimo);

    if ($stmt->execute()) {
        echo "Producto registrado con éxito.";
    } else {
        echo "Error al registrar el producto.";
    }

    $stmt->close();
}
// ==========================
// FUNCION FILTRAR
// ==========================

function filtrarProducto($conn, $data) {
    $codigo = $data['codigo'];

    // Consulta para filtrar productos por código
    $query = "SELECT * FROM productos WHERE codigo = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $result = $stmt->get_result();

    // Crear un array para almacenar los productos encontrados
    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row; // Agregar el producto al array
    }

    // Devolver los productos encontrados como JSON
    if (count($productos) > 0) {
        echo json_encode(["success" => true, "productos" => $productos]);
    } else {
        echo json_encode(["success" => false, "message" => "No se encontraron productos con ese código."]);
    }

    $stmt->close();
}

$conn->close();
?>
