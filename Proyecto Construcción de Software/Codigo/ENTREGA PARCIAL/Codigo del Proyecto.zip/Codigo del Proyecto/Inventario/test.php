<?php
include('includes/config.php');

echo "Conectado correctamente a la base de datos 🚀";
?>
