<?php
$host = "localhost";
$usuario = "root";
$contrasena = "2004";
$base_datos = "inventario_db";

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verifica la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
